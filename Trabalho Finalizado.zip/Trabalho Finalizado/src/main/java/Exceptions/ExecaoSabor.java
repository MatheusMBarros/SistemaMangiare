package Exceptions;

public class ExecaoSabor extends Exception{
    public ExecaoSabor() {
        super("Escolha no mpinimo um sabor");
    }
}
